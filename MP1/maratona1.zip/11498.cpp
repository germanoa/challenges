#include <iostream>
using namespace std;

int main()
{
	while (1) {
	
		int k;
		cin >> k;

		if(k == 0) break;

		int divX, divY, x, y;

		cin >> divX >> divY;

		while (k--)
		{
			cin >> x >> y;
			
			if(x > divX && y > divY) cout << "NE" << endl;
			else if(x > divX && y < divY) cout << "SE" << endl;
			else if(x < divX && y < divY) cout << "SO" << endl;
			else if(x < divX && y > divY) cout << "NO" << endl;
			else cout << "divisa" << endl;
		}
	}

	return 0;
}

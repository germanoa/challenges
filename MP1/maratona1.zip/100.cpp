// uva100.cpp



#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;

void engine() {


}

int main()
{
//	while(engine())
//		;

/*
1. 		 input n
2. 		 print n
3. 		 if n = 1 then STOP
4. 		 		 if n is odd then  tex2html_wrap_inline44
5. 		 		 else  tex2html_wrap_inline46
6. 		 GOTO 2
*/

    int ini=0;
    int fim=0;

    while (cin >> ini >> fim)
    {
        int inia=ini;
        int fima=fim;
        if(ini>fim)
        {
            inia=fim;
            fima=ini;
        }

        int grand=0;
        for(int i=inia;i<=fima;i++)
        {
            int n=i;
            //cout << "hi1" << n << endl;
            int counter = 1;
            while (n!=1)
            {
                //cout << n << " ";
                counter++;
                if(n%2!=0)
                {
                    n=3*n+1;
                    //cout << "hi2a"<< n << endl;
                }
                else
                {
                    n=n/2;
                    //cout << "hi2b"<< n << endl;
                }
                //cout << "hi2"<< n << endl;
            }
            if(counter>grand)
                grand=counter;
            //cout << "hi3"<< endl;
        }
        cout << ini << " " << fim << " " << grand << endl;
    }
}


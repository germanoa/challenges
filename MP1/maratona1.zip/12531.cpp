#include <iostream>
using namespace std;

int angulo;

int main()
{
	while (cin >> angulo)
	{

		if(angulo % 6 == 0)
			cout << "Y" << endl;

		else cout << "N" << endl;

	}

	return 0;

}
